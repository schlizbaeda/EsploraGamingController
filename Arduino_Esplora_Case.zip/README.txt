                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:45880
Arduino Esplora Case by JoeyC is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

This case is for the Arduino Esplora board. It includes a bezel for use with the Adafruit 1.8" display. It has clear windows with light guides for the RGB LED and light sensor, and tubes to guide sound to/from the beeper and mic. All the buttons including reset are brought up to the case top.

# Instructions

1. Print the Bottom, Top, Buttons, Bezel, and LightGuides STL files at .3mm layer height, 50% fill, 0 extra shells. I recomend PLA for the Top and Bottom to minimize shrinkage issues. You may want to use support for the Top.stl file because of the tabs on the switch pushrods.

2. Print the Windows.stl file using clear PLA at .3mm layer height, 100% fill, 0 extra shells.

3. Glue the connector cover to the case bottom. It goes in the slot in the back all the way down with the thinner side up so the top case can go inside it. (I recoment test fitting everything together before gluing anything)

4. Put the windows in the holes over the light sensor and the LEDs. They should be a tight fit and not need any glue. You may need to trim them to fit. I find that putting them in smooth side out looks best.

5. Put the switch pushrods (the round things with the tabs on the side) into the holes in the top over the switches. They go with the tabs to the bottom. Make sure the slide freely. Glue the button tops onto the pushrods.

6. Install the Esplora board into the case bottom. It is attached with #2 x 3/16 screws.

steps 7 and 8 are for using the display:

7. Plug the display onto the Esplora board. I used two extra connector pins with the top halfs cut down to the plastic to support the other side of the display.

8. Put the case top on the case bottom. Line up the display bezel over the display and tape it in place on the case. Take off the top and glue the bezel in from the back.

9. Put the reset pushrod into the hole in the top over the reset switch. Make sure it slides freely.

10. Put the case top onto the bottom. Do this with the top and bottom upright so the reset pushrod does not fall out of the top.

Parts list:
1. Arduino Esplora board: Currently only avalible at Radio Shack. Online or in a store.
2. Display: Adafruit 1.8" display.  http://www.adafruit.com/products/358
3. 2 x 3/16 sheet meatal screws: J&R Hobby hardware.  http://www.jrhobbyhardware.com/shop/index.php?main_page=product_info&cPath=122&products_id=315